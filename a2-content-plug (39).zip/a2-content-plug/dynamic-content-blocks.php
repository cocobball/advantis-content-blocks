<?php
/**
 * Plugin Name: Dynamic Content Blocks Plugin
 * Description: Dynamically generate and display content blocks based on user-selected filters.
 * Version: 1.0.0
 * Author: Your Name
 * Text Domain: dynamic-content-blocks
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

// Define constants.
define( 'DCB_VERSION', '1.0.0' );
define( 'DCB_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'DCB_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Include required files.
require_once DCB_PLUGIN_DIR . 'includes/class-dcb-shortcode.php';
require_once DCB_PLUGIN_DIR . 'includes/class-dcb-database.php';
require_once DCB_PLUGIN_DIR . 'includes/class-dcb-content-handler.php';
require_once DCB_PLUGIN_DIR . 'includes/class-dcb-url-shortcode.php';
require_once DCB_PLUGIN_DIR . 'includes/class-dcb-combo-auto-add.php'; // Include the new Combo Auto Add class
require_once DCB_PLUGIN_DIR . 'admin/class-dcb-usage.php';

// Include admin files if in the admin area.
if ( is_admin() ) {
    require_once DCB_PLUGIN_DIR . 'admin/class-dcb-admin.php';
    require_once DCB_PLUGIN_DIR . 'admin/class-dcb-import-export.php';
    require_once DCB_PLUGIN_DIR . 'admin/class-dcb-spreadsheet-editor.php';
    require_once DCB_PLUGIN_DIR . 'admin/class-dcb-settings.php';
}

// Activation and uninstall hooks.
register_activation_hook( __FILE__, array( 'DCB_Database', 'create_table' ) );
register_uninstall_hook( __FILE__, 'dcb_uninstall_plugin' );

// Uninstall function.
function dcb_uninstall_plugin() {
    // Uninstall code can be added here.
}

// Initialize the plugin.
function dcb_init_plugin() {
    require_once DCB_PLUGIN_DIR . 'includes/class-dcb-ajax-handler.php';

    // Initialize classes needed for both admin and frontend
    new DCB_Combo_Auto_Add();

    if ( is_admin() ) {
        // Initialize admin classes.
        new DCB_Admin();
        new DCB_Settings();
        new DCB_Import_Export();
        new DCB_Ajax_Handler();
        new DCB_Spreadsheet_Editor();
    }

    if ( ! is_admin() ) {
        // Initialize the shortcode class.
        new DCB_Shortcode();
        
        // Initialize the URL-based shortcode class.
        new DCB_URL_Shortcode();
    }
}

add_action( 'plugins_loaded', 'dcb_init_plugin' );
