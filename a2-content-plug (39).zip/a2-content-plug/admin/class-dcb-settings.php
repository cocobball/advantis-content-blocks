<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class DCB_Settings {
    public function __construct() {
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_settings_assets' ) );
    }

    public function add_settings_page() {
        add_submenu_page(
            'dcb_content_blocks', // Parent slug
            __( 'DCB Settings', 'dynamic-content-blocks' ),
            __( 'Settings', 'dynamic-content-blocks' ),
            'manage_options',
            'dcb_settings',
            array( $this, 'render_settings_page' )
        );
    }

    public function register_settings() {
        // Register settings
        register_setting( 'dcb_settings_group', 'dcb_openai_api_key', 'sanitize_text_field' );
        register_setting( 'dcb_settings_group', 'dcb_prompt_templates', array(
            'type' => 'array',
            'sanitize_callback' => array( $this, 'sanitize_prompt_templates' ),
            'default' => array(),
        ));

        // New settings for "Auto Generate All" feature
        register_setting( 'dcb_settings_group', 'dcb_auto_generate_enabled' );
        register_setting( 'dcb_settings_group', 'dcb_default_combo_type' );
        register_setting( 'dcb_settings_group', 'dcb_default_content_block' );

        // New setting for enabling/disabling the Combo Auto Add feature
        register_setting( 'dcb_settings_group', 'dcb_combo_auto_add_enabled', array(
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => '1',
        ));

        // Add settings section
        add_settings_section(
            'dcb_settings_section',
            __( 'Dynamic Content Blocks Settings', 'dynamic-content-blocks' ),
            null,
            'dcb_settings_page'
        );

        // Add OpenAI API Key field
        add_settings_field(
            'dcb_openai_api_key',
            __( 'OpenAI API Key', 'dynamic-content-blocks' ),
            array( $this, 'render_openai_api_key_field' ),
            'dcb_settings_page',
            'dcb_settings_section'
        );

        // Add Prompt Templates field
        add_settings_field(
            'dcb_prompt_templates',
            __( 'Prompt Templates', 'dynamic-content-blocks' ),
            array( $this, 'render_prompt_templates_field' ),
            'dcb_settings_page',
            'dcb_settings_section'
        );

        // Add "Auto Generate All" feature fields
        add_settings_field(
            'dcb_auto_generate_enabled',
            __( 'Enable Auto Generate All Feature', 'dynamic-content-blocks' ),
            array( $this, 'render_auto_generate_enabled_field' ),
            'dcb_settings_page',
            'dcb_settings_section'
        );
        add_settings_field(
            'dcb_default_combo_type',
            __( 'Default Combo Type', 'dynamic-content-blocks' ),
            array( $this, 'render_default_combo_type_field' ),
            'dcb_settings_page',
            'dcb_settings_section'
        );
        add_settings_field(
            'dcb_default_content_block',
            __( 'Default Content Block Number', 'dynamic-content-blocks' ),
            array( $this, 'render_default_content_block_field' ),
            'dcb_settings_page',
            'dcb_settings_section'
        );

        // Add setting field for enabling/disabling the Combo Auto Add feature
        add_settings_field(
            'dcb_combo_auto_add_enabled',
            __( 'Enable Combo Auto Add Feature', 'dynamic-content-blocks' ),
            array( $this, 'render_combo_auto_add_enabled_field' ),
            'dcb_settings_page',
            'dcb_settings_section'
        );
    }

    // Sanitize the prompt templates array
    public function sanitize_prompt_templates( $input ) {
        $sanitized = array();
        if ( is_array( $input ) ) {
            foreach ( $input as $key => $value ) {
                if ( isset( $value['combo_type'] ) && isset( $value['prompt'] ) ) {
                    $sanitized[ $key ] = array(
                        'combo_type' => sanitize_text_field( trim( $value['combo_type'] ) ),
                        'prompt'     => wp_kses_post( $value['prompt'] ),
                    );
                }
            }
        }
        return $sanitized;
    }

    // Render the OpenAI API Key field
    public function render_openai_api_key_field() {
        $api_key = get_option( 'dcb_openai_api_key' );
        ?>
        <input type="password" name="dcb_openai_api_key" value="<?php echo esc_attr( $api_key ); ?>" size="50" />
        <p class="description"><?php _e( 'Enter your OpenAI API key. This will be used to generate content.', 'dynamic-content-blocks' ); ?></p>
        <?php
    }

    // Render the Prompt Templates field
    public function render_prompt_templates_field() {
        $prompt_templates = get_option( 'dcb_prompt_templates', array() );
        ?>
        <table id="dcb-prompt-templates-table">
            <thead>
                <tr>
                    <th><?php _e( 'Combo Type', 'dynamic-content-blocks' ); ?></th>
                    <th><?php _e( 'Prompt Template', 'dynamic-content-blocks' ); ?></th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php if ( ! empty( $prompt_templates ) ) : ?>
                    <?php foreach ( $prompt_templates as $index => $template ) : ?>
                        <tr>
                            <td><input type="text" name="dcb_prompt_templates[<?php echo $index; ?>][combo_type]" value="<?php echo esc_attr( $template['combo_type'] ); ?>" /></td>
                            <td><textarea name="dcb_prompt_templates[<?php echo $index; ?>][prompt]" rows="3" cols="50"><?php echo esc_textarea( $template['prompt'] ); ?></textarea></td>
                            <td><button class="button dcb-remove-prompt"><?php _e( 'Remove', 'dynamic-content-blocks' ); ?></button></td>
                        </tr>
                    <?php endforeach; ?>
                <?php endif; ?>
            </tbody>
        </table>
        <button class="button" id="dcb-add-prompt"><?php _e( 'Add Prompt', 'dynamic-content-blocks' ); ?></button>
        <p class="description"><?php _e( 'Use placeholders like {state}, {city}, {specialty}, {combo_type}.', 'dynamic-content-blocks' ); ?></p>
        <?php
    }

    // Render Enable/Disable Auto Generate All feature field
    public function render_auto_generate_enabled_field() {
        ?>
        <input type="checkbox" id="dcb_auto_generate_enabled" name="dcb_auto_generate_enabled" value="1" <?php checked(1, get_option('dcb_auto_generate_enabled'), true); ?> />
        <label for="dcb_auto_generate_enabled"><?php _e( 'Enable Auto Generate All Feature', 'dynamic-content-blocks' ); ?></label>
        <?php
    }

    // Render Default Combo Type field
    public function render_default_combo_type_field() {
        $default_combo_type = get_option( 'dcb_default_combo_type' );
        ?>
        <input type="text" id="dcb_default_combo_type" name="dcb_default_combo_type" value="<?php echo esc_attr( $default_combo_type ); ?>" />
        <p class="description"><?php _e( 'Set the default combo type for the Auto Generate All feature.', 'dynamic-content-blocks' ); ?></p>
        <?php
    }

    // Render Default Content Block field
    public function render_default_content_block_field() {
        $default_content_block = get_option( 'dcb_default_content_block' );
        ?>
        <select id="dcb_default_content_block" name="dcb_default_content_block">
            <option value="1" <?php selected( $default_content_block, '1' ); ?>>1</option>
            <option value="2" <?php selected( $default_content_block, '2' ); ?>>2</option>
        </select>
        <p class="description"><?php _e( 'Choose the default content block for the Auto Generate All feature.', 'dynamic-content-blocks' ); ?></p>
        <?php
    }

    // Render the Combo Auto Add Enabled field
    public function render_combo_auto_add_enabled_field() {
        ?>
        <input type="checkbox" id="dcb_combo_auto_add_enabled" name="dcb_combo_auto_add_enabled" value="1" <?php checked( '1', get_option( 'dcb_combo_auto_add_enabled', '1' ), true ); ?> />
        <label for="dcb_combo_auto_add_enabled"><?php _e( 'Enable Combo Auto Add Feature', 'dynamic-content-blocks' ); ?></label>
        <?php
    }

    // Enqueue JavaScript for the settings page
    public function enqueue_settings_assets( $hook_suffix ) {
        error_log( 'enqueue_settings_assets called with hook: ' . $hook_suffix );  // Debugging hook value
        if ( strpos( $hook_suffix, 'dcb_settings' ) === false ) {
            return;
        }
        wp_enqueue_script( 'dcb-settings-js', DCB_PLUGIN_URL . 'assets/js/dcb-settings.js', array( 'jquery' ), time(), true );
        wp_localize_script( 'dcb-settings-js', 'dcbSettings', array(
            'removeText' => __( 'Remove', 'dynamic-content-blocks' ),
        ));
    }

    // Render the settings page
    public function render_settings_page() {
        ?>
        <div class="wrap">
            <h1><?php _e( 'Dynamic Content Blocks Settings', 'dynamic-content-blocks' ); ?></h1>
            <form method="post" action="options.php">
                <?php
                settings_fields( 'dcb_settings_group' );
                do_settings_sections( 'dcb_settings_page' );
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }
}
?>
