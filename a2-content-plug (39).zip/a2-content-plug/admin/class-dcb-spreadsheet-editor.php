<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class DCB_Spreadsheet_Editor {

    public function __construct() {
        // Register the shortcode to display the spreadsheet editor
        add_shortcode('dcb_spreadsheet_editor', array($this, 'render_spreadsheet_editor'));
    }

    /**
     * Fetch content blocks from the database or wherever they're stored.
     */
    public function get_content_blocks() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'dcb_content_blocks';
        $results = $wpdb->get_results("SELECT id, state, city, specialty, combo_type, content_block, content_block_2, last_updated FROM $table_name", ARRAY_A);

        // Remove slashes from all retrieved fields to prevent backslashes on display
        $results = stripslashes_deep($results);

        return $results;
    }

    /**
     * Render the spreadsheet editor.
     */
    public function render_spreadsheet_editor() {
        // Fetch content blocks
        $content_blocks = $this->get_content_blocks();

        // Get settings for Auto Generate All feature
        $auto_generate_enabled = get_option( 'dcb_auto_generate_enabled', false );
        $default_combo_type = get_option( 'dcb_default_combo_type', '' );
        $default_content_block = get_option( 'dcb_default_content_block', '1' );

        ob_start(); ?>
        
        <div class="dcb-spreadsheet-editor">
            <h2><?php _e('Content Block Spreadsheet', 'dynamic-content-blocks'); ?></h2>
            
            <!-- Import/Export Functionality -->
            <form method="post" enctype="multipart/form-data" action="<?php echo admin_url( 'admin-post.php' ); ?>">
                <?php wp_nonce_field( 'dcb_import_nonce' ); ?>
                <input type="hidden" name="action" value="dcb_import">
                <input type="file" name="dcb_csv_file" accept=".csv" required>
                <input type="submit" value="<?php _e( 'Import CSV', 'dynamic-content-blocks' ); ?>" class="button button-primary">
            </form>
            
            <!-- Export CSV -->
            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: inline;">
                <?php wp_nonce_field( 'dcb_export_nonce' ); ?>
                <input type="hidden" name="action" value="dcb_export">
                <input type="submit" value="<?php _e( 'Export CSV', 'dynamic-content-blocks' ); ?>" class="button">
            </form>

            <!-- Auto Generate All Section -->
            <?php if ( $auto_generate_enabled ) : ?>
            <div id="dcb-auto-generate-all" style="margin-top: 20px;">
                <h2><?php _e( 'Auto Generate All', 'dynamic-content-blocks' ); ?></h2>
                <label for="dcb-combo-type"><?php _e( 'Combo Type:', 'dynamic-content-blocks' ); ?></label>
                <input type="text" id="dcb-combo-type" name="dcb-combo-type" value="<?php echo esc_attr( $default_combo_type ); ?>" style="margin-right: 20px;" />

                <label for="dcb-content-block-select"><?php _e( 'Content Block:', 'dynamic-content-blocks' ); ?></label>
                <select id="dcb-content-block-select" name="dcb-content-block-select" style="margin-right: 20px;">
                    <option value="1" <?php selected( $default_content_block, '1' ); ?>>Content Block 1</option>
                    <option value="2" <?php selected( $default_content_block, '2' ); ?>>Content Block 2</option>
                </select>

                <button class="button button-primary" id="dcb-auto-generate-all-btn"><?php _e( 'Auto Generate All', 'dynamic-content-blocks' ); ?></button>
            </div>
            <?php endif; ?>

            <!-- Spreadsheet Table -->
            <table id="dcb-spreadsheet-table">
                <thead>
                    <tr>
                        <th><?php _e('State', 'dynamic-content-blocks'); ?></th>
                        <th><?php _e('City', 'dynamic-content-blocks'); ?></th>
                        <th><?php _e('Specialty', 'dynamic-content-blocks'); ?></th>
                        <th><?php _e('Combo Type', 'dynamic-content-blocks'); ?></th>
                        <th><?php _e('Content Block', 'dynamic-content-blocks'); ?></th>
                        <th><?php _e('Content Block 2', 'dynamic-content-blocks'); ?></th>
                        <th><?php _e('Last Updated', 'dynamic-content-blocks'); ?></th>
                        <th><?php _e('Actions', 'dynamic-content-blocks'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (!empty($content_blocks)) : ?>
                        <?php foreach ($content_blocks as $content_block) : ?>
                            <tr data-id="<?php echo esc_attr($content_block['id']); ?>">
                                <td contenteditable="true" data-field="state"><?php echo isset($content_block['state']) ? esc_html($content_block['state']) : ''; ?></td>
                                <td contenteditable="true" data-field="city"><?php echo isset($content_block['city']) ? esc_html($content_block['city']) : ''; ?></td>
                                <td contenteditable="true" data-field="specialty"><?php echo isset($content_block['specialty']) ? esc_html($content_block['specialty']) : ''; ?></td>
                                <td contenteditable="true" data-field="combo_type"><?php echo isset($content_block['combo_type']) ? esc_html($content_block['combo_type']) : ''; ?></td>
                                <td contenteditable="true" data-field="content_block"><?php echo isset($content_block['content_block']) ? esc_textarea($content_block['content_block']) : ''; ?></td>
                                <td contenteditable="true" data-field="content_block_2"><?php echo isset($content_block['content_block_2']) ? esc_textarea($content_block['content_block_2']) : ''; ?></td>
                                <td><?php echo isset($content_block['last_updated']) ? esc_html($content_block['last_updated']) : ''; ?></td>
                                <td>
                                    <button class="button dcb-generate-row"><?php _e('Generate', 'dynamic-content-blocks'); ?></button>
                                    <button class="button dcb-generate-row-2"><?php _e('Generate 2', 'dynamic-content-blocks'); ?></button>
                                    <button class="button dcb-delete-row"><?php _e('Delete', 'dynamic-content-blocks'); ?></button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else : ?>
                        <tr>
                            <td colspan="8"><?php _e('No content blocks available.', 'dynamic-content-blocks'); ?></td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <!-- Add New Row and Delete All Buttons -->
            <button id="dcb-add-row" class="button"><?php _e('Add New Row', 'dynamic-content-blocks'); ?></button>
            <button id="dcb-delete-all" class="button"><?php _e('Delete All', 'dynamic-content-blocks'); ?></button>

        </div>

        <?php
        return ob_get_clean();
    }
}
