<?php

if ( ! defined( 'ABSPATH' ) ) exit;

class DCB_Admin {
    public function __construct() {
        // Hook for adding admin menu
        add_action( 'admin_menu', array( $this, 'add_admin_menu' ) );
        // Hook for enqueuing admin assets
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );
    }

    // Function to add the admin menu and submenu
    public function add_admin_menu() {
        add_menu_page(
            __( 'Dynamic Content Blocks', 'dynamic-content-blocks' ),
            __( 'Content Blocks', 'dynamic-content-blocks' ),
            'manage_options',
            'dcb_content_blocks',
            array( $this, 'render_spreadsheet_editor' ),
            'dashicons-grid-view',
            6
        );

        // Add the submenu for Usage instructions
        add_submenu_page(
            'dcb_content_blocks',
            __( 'Usage', 'dynamic-content-blocks' ),
            __( 'Usage', 'dynamic-content-blocks' ),
            'manage_options',
            'dcb_usage',
            array( 'DCB_Usage', 'render_usage_page' )
        );
    }

    // Function to enqueue CSS and JS files for the admin panel
    public function enqueue_admin_assets( $hook ) {
        // Ensure scripts and styles are only loaded on the correct page
        if ( $hook !== 'toplevel_page_dcb_content_blocks' && $hook !== 'dynamic-content-blocks_page_dcb_usage') {
            return;
        }

        // Enhanced error logging
        if (!defined('DCB_PLUGIN_URL') || !defined('DCB_VERSION')) {
            error_log('Missing plugin constants DCB_PLUGIN_URL or DCB_VERSION.');
        }

        // Enqueue styles and scripts
        wp_enqueue_style( 'dcb-admin-css', DCB_PLUGIN_URL . 'assets/css/dcb-admin.css', array(), DCB_VERSION );
        wp_enqueue_script( 'dcb-admin-js', DCB_PLUGIN_URL . 'assets/js/dcb-admin.js', array( 'jquery' ), DCB_VERSION, true );

        // Localize script to pass settings and nonce to JavaScript
        wp_localize_script( 'dcb-admin-js', 'dcbAjax', array(
            'ajax_url'               => admin_url( 'admin-ajax.php' ),
            'nonce'                  => wp_create_nonce( 'dcb_ajax_nonce' ),
            'default_combo_type'     => get_option( 'dcb_default_combo_type', '' ),
            'default_content_block'  => get_option( 'dcb_default_content_block', '1' ),
            'auto_generate_enabled'  => get_option( 'dcb_auto_generate_enabled', false ),
        ));

        // Log if scripts fail to load
        error_log('Scripts enqueued successfully.');
    }

    // Function to render the spreadsheet editor page in the admin panel
    public function render_spreadsheet_editor() {
        $spreadsheet_editor = new DCB_Spreadsheet_Editor();
        echo $spreadsheet_editor->render_spreadsheet_editor();
    }
}
