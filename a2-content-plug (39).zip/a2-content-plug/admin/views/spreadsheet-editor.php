<?php if ( ! defined( 'ABSPATH' ) ) exit; ?>

<div class="wrap">
    <h1><?php _e( 'Content Blocks Editor', 'dynamic-content-blocks' ); ?></h1>
    <!-- Import/Export Buttons -->
    <form method="post" enctype="multipart/form-data" action="<?php echo admin_url( 'admin-post.php' ); ?>">
        <?php wp_nonce_field( 'dcb_import_nonce' ); ?>
        <input type="hidden" name="action" value="dcb_import">
        <input type="file" name="dcb_csv_file" accept=".csv" required>
        <input type="submit" value="<?php _e( 'Import CSV', 'dynamic-content-blocks' ); ?>" class="button button-primary">
    </form>
    <a href="<?php echo admin_url( 'admin-post.php?action=dcb_export' ); ?>" class="button"><?php _e( 'Export CSV', 'dynamic-content-blocks' ); ?></a>

    <!-- Auto Generate All Section -->
    <div id="dcb-auto-generate-all" style="margin-top: 20px;">
        <h2><?php _e( 'Auto Generate All', 'dynamic-content-blocks' ); ?></h2>
        <label for="dcb-combo-type"><?php _e( 'Combo Type:', 'dynamic-content-blocks' ); ?></label>
        <input type="text" id="dcb-combo-type" name="dcb-combo-type" style="margin-right: 20px;" />

        <label for="dcb-content-block-select"><?php _e( 'Content Block:', 'dynamic-content-blocks' ); ?></label>
        <select id="dcb-content-block-select" name="dcb-content-block-select" style="margin-right: 20px;">
            <option value="1"><?php _e( 'Content Block 1', 'dynamic-content-blocks' ); ?></option>
            <option value="2"><?php _e( 'Content Block 2', 'dynamic-content-blocks' ); ?></option>
        </select>

        <button class="button button-primary" id="dcb-auto-generate-all-btn"><?php _e( 'Auto Generate All', 'dynamic-content-blocks' ); ?></button>
    </div>

    <!-- Spreadsheet Editor Table -->
    <table class="wp-list-table widefat fixed striped" style="margin-top: 20px;">
        <thead>
            <tr>
                <th><?php _e( 'State', 'dynamic-content-blocks' ); ?></th>
                <th><?php _e( 'City', 'dynamic-content-blocks' ); ?></th>
                <th><?php _e( 'Specialty', 'dynamic-content-blocks' ); ?></th>
                <th><?php _e( 'Combo Type', 'dynamic-content-blocks' ); ?></th>
                <th><?php _e( 'Content Block', 'dynamic-content-blocks' ); ?></th>
                <th><?php _e( 'Last Updated', 'dynamic-content-blocks' ); ?></th>
                <th><?php _e( 'Actions', 'dynamic-content-blocks' ); ?></th>
            </tr>
        </thead>
        <tbody>
            <?php
            $content_handler = new DCB_Content_Handler();
            $content_blocks  = $content_handler->get_all_content_blocks();
            foreach ( $content_blocks as $block ) :
            ?>
                <tr data-id="<?php echo esc_attr( $block->id ); ?>">
                    <td contenteditable="true" data-field="state"><?php echo esc_html( $block->state ); ?></td>
                    <td contenteditable="true" data-field="city"><?php echo esc_html( $block->city ); ?></td>
                    <td contenteditable="true" data-field="specialty"><?php echo esc_html( $block->specialty ); ?></td>
                    <td contenteditable="true" data-field="combo_type"><?php echo esc_html( $block->combo_type ); ?></td>
                    <td contenteditable="true" data-field="content_block"><?php echo esc_html( $block->content_block ); ?></td>
                    <td><?php echo esc_html( $block->last_updated ); ?></td>
                    <td><button class="button dcb-delete-row"><?php _e( 'Delete', 'dynamic-content-blocks' ); ?></button></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <button class="button" id="dcb-add-row"><?php _e( 'Add Row', 'dynamic-content-blocks' ); ?></button>
</div>
