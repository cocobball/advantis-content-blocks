<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class DCB_Usage {
    public function __construct() {
        // Enqueue any scripts or styles if needed.
    }

    public static function render_usage_page() {
        ?>
        <div class="wrap">
            <h1><?php _e( 'Usage Instructions', 'dynamic-content-blocks' ); ?></h1>
            <p><?php _e( 'Use the following shortcode to display content blocks based on state, city, specialty, and block number:', 'dynamic-content-blocks' ); ?></p>
            <pre>[dcb_content_block state="Texas" city="Dallas" block_number="1"]</pre>
            <p><?php _e( 'Available attributes:', 'dynamic-content-blocks' ); ?></p>
            <ul>
                <li><strong>state</strong>: <?php _e( 'The state name', 'dynamic-content-blocks' ); ?></li>
                <li><strong>city</strong>: <?php _e( 'The city name', 'dynamic-content-blocks' ); ?></li>
                <li><strong>specialty</strong>: <?php _e( 'The specialty', 'dynamic-content-blocks' ); ?></li>
                <li><strong>block_number</strong>: <?php _e( 'The content block number to display (1 or 2)', 'dynamic-content-blocks' ); ?></li>
            </ul>
            <p><?php _e( 'Examples for Block 1 and Block 2 display:', 'dynamic-content-blocks' ); ?></p>
            <pre>[dcb_content_block specialty="PCU" block_number="1"]</pre>
            <pre>[dcb_content_block specialty="PCU" block_number="2"]</pre>
            <pre>[dcb_content_block state="Texas" city="Austin" block_number="1"]</pre>
            <pre>[dcb_content_block state="Texas" specialty="ER" block_number="2"]</pre>

            <h2><?php _e( 'Chart GPT Integration', 'dynamic-content-blocks' ); ?></h2>
            <p><?php _e( 'The Chart GPT feature currently supports content only in Block 1. You can set prompts for Chart GPT in the settings page, where each content block type can be matched to a specific prompt based on your preference.', 'dynamic-content-blocks' ); ?></p>

            <h2><?php _e( 'Recent Updates', 'dynamic-content-blocks' ); ?></h2>
            <p><?php _e( 'This latest version adds support for HTML content within content blocks, allowing for richer formatting and customization options.', 'dynamic-content-blocks' ); ?></p>

            <h2><?php _e( 'Upcoming Features', 'dynamic-content-blocks' ); ?></h2>
            <ul>
                <li><?php _e( 'Expand Chart GPT functionality to support content Block 2.', 'dynamic-content-blocks' ); ?></li>
                <li><?php _e( 'Allow for multiple prompt processing at once, enabling more than one content box to be generated simultaneously.', 'dynamic-content-blocks' ); ?></li>
                <li><?php _e( 'Fix the prompt date-saving error in the database table.', 'dynamic-content-blocks' ); ?></li>
                <li><?php _e( 'Enhance prompt customization by adding additional prompt options.', 'dynamic-content-blocks' ); ?></li>
            </ul>
        </div>
        <?php
    }
}
