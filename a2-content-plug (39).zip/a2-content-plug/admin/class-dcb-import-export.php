<?php

class DCB_Import_Export {
    public function __construct() {
        // Add actions to handle import and export requests.
        add_action( 'admin_post_dcb_export', array( $this, 'export_csv' ) );
        add_action( 'admin_post_dcb_import', array( $this, 'import_csv' ) );
    }

    public function export_csv() {
        // Ensure the user has the right permissions.
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'dynamic-content-blocks' ) );
        }

        // Verify the nonce to protect against CSRF attacks.
        if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'dcb_export_nonce' ) ) {
            wp_die( __( 'Invalid nonce.', 'dynamic-content-blocks' ) );
        }

        // Fetch data from the database.
        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';
        $rows = $wpdb->get_results( "SELECT * FROM $table_name", ARRAY_A );

        if ( empty( $rows ) ) {
            wp_die( __( 'No data found in the table.', 'dynamic-content-blocks' ) );
        }

        // Set headers to force download.
        header( 'Content-Type: text/csv; charset=utf-8' );
        header( 'Content-Disposition: attachment; filename=dcb-content-blocks.csv' );

        // Open output stream.
        $output = fopen( 'php://output', 'w' );

        // Output column headings, including 'Content Block 2'
        fputcsv( $output, array( 'State', 'City', 'Specialty', 'Combo Type', 'Content Block', 'Content Block 2', 'Last Updated' ) );

        // Output each row.
        foreach ( $rows as $row ) {
            $data_row = array(
                $row['state'],
                $row['city'],
                $row['specialty'],
                $row['combo_type'],
                $row['content_block'],
                $row['content_block_2'], // Include content_block_2 in data row
                $row['last_updated'],
            );
            fputcsv( $output, $data_row );
        }

        // Close the output stream.
        fclose( $output );
        exit;
    }

    public function import_csv() {
        // Ensure the user has the right permissions.
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'dynamic-content-blocks' ) );
        }

        // Verify the nonce to protect against CSRF attacks.
        check_admin_referer( 'dcb_import_nonce' );

        // Check if the CSV file was uploaded successfully.
        if ( isset( $_FILES['dcb_csv_file'] ) && $_FILES['dcb_csv_file']['error'] === UPLOAD_ERR_OK ) {
            $file = $_FILES['dcb_csv_file']['tmp_name'];

            if ( file_exists( $file ) ) {
                $handle = fopen( $file, 'r' );

                if ( $handle ) {
                    $content_handler = new DCB_Content_Handler();

                    // Get the CSV header row.
                    $header = fgetcsv( $handle, 1000, ',' );

                    // Process the CSV rows.
                    while ( ( $data = fgetcsv( $handle, 1000, ',' ) ) !== false ) {
                        // Ensure the CSV row has enough columns (at least 6).
                        if ( count( $data ) >= 6 ) {
                            // Handle cases where values are empty.
                            $state = !empty($data[0]) ? sanitize_text_field( $data[0] ) : '';
                            $city = !empty($data[1]) ? sanitize_text_field( $data[1] ) : '';
                            $specialty = !empty($data[2]) ? sanitize_text_field( $data[2] ) : '';
                            $combo_type = !empty($data[3]) ? sanitize_text_field( $data[3] ) : '';
                            $content_block = !empty($data[4]) ? wp_kses_post( $data[4] ) : ''; // Allows safe HTML
                            $content_block_2 = !empty($data[5]) ? wp_kses_post( $data[5] ) : ''; // Allows safe HTML

                            // Insert the content block into the database.
                            $result = $content_handler->insert_content_block( $state, $city, $specialty, $combo_type, $content_block, $content_block_2 );

                            if ( ! $result ) {
                                error_log( 'Failed to insert content block: ' . print_r( $data, true ) );
                            }
                        } else {
                            error_log( 'CSV row does not contain enough columns: ' . print_r( $data, true ) );
                        }
                    }

                    // Close the file after processing.
                    fclose( $handle );

                    // Redirect to success page.
                    wp_redirect( admin_url( 'admin.php?page=dcb_content_blocks&import=success' ) );
                    exit;
                } else {
                    error_log( 'Error opening the file: ' . $file );
                    wp_redirect( admin_url( 'admin.php?page=dcb_content_blocks&import=error' ) );
                    exit;
                }
            } else {
                error_log( 'Uploaded file does not exist: ' . $file );
                wp_redirect( admin_url( 'admin.php?page=dcb_content_blocks&import=error' ) );
                exit;
            }
        } else {
            error_log( 'Error uploading CSV file: ' . print_r( $_FILES['dcb_csv_file'], true ) );
            wp_redirect( admin_url( 'admin.php?page=dcb_content_blocks&import=error' ) );
            exit;
        }
    }
}
