<?php

class DCB_Ajax_Handler {
    public function __construct() {
        add_action( 'wp_ajax_dcb_save_cell', array( $this, 'save_cell' ) );
        add_action( 'wp_ajax_dcb_add_row', array( $this, 'add_row' ) );
        add_action( 'wp_ajax_dcb_delete_row', array( $this, 'delete_row' ) );
        add_action( 'wp_ajax_dcb_delete_all', array( $this, 'delete_all_rows' ) );
        add_action( 'wp_ajax_dcb_generate_content', array( $this, 'generate_content' ) );
        add_action( 'wp_ajax_dcb_get_entry_count', array( $this, 'get_entry_count' ) );
        add_action( 'wp_ajax_dcb_bulk_generate_content', array( $this, 'bulk_generate_content' ) );
    }

    // Method to delete a row via AJAX
    public function delete_row() {
        error_log('Received nonce: ' . $_POST['nonce']);
        
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'dcb_ajax_nonce' ) ) {
            wp_send_json_error( 'Invalid nonce' );
        }

        $row_id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;

        if ( $row_id <= 0 ) {
            wp_send_json_error( 'Invalid row ID' );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';
        $deleted = $wpdb->delete( $table_name, array( 'id' => $row_id ) );

        if ( $deleted ) {
            wp_send_json_success();
        } else {
            wp_send_json_error( 'Error deleting the row' );
        }
    }

    // Method to delete all rows via AJAX
    public function delete_all_rows() {
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'dcb_ajax_nonce' ) ) {
            wp_send_json_error( 'Invalid nonce' );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';
        $deleted = $wpdb->query( "DELETE FROM $table_name" );

        if ( $deleted !== false ) {
            wp_send_json_success();
        } else {
            wp_send_json_error( 'Error deleting all rows' );
        }
    }

    // Method to save a cell value via AJAX
    public function save_cell() {
        error_log('AJAX save_cell called with data: ' . print_r($_POST, true));

        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'dcb_ajax_nonce' ) ) {
            wp_send_json_error( 'Invalid nonce' );
        }

        $row_id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
        $field = isset( $_POST['field'] ) ? sanitize_text_field( $_POST['field'] ) : '';
        $value = isset( $_POST['value'] ) ? $_POST['value'] : '';

        if ( $field === 'content_block' || $field === 'content_block_2' ) {
            $value = wp_kses_post( $value );
        } else {
            $value = sanitize_text_field( $value );
        }

        if ( $row_id <= 0 || empty( $field ) ) {
            wp_send_json_error( 'Invalid input' );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';
        $data = array(
            $field => $value,
            'last_updated' => current_time('mysql')
        );
        $where = array( 'id' => $row_id );

        $updated = $wpdb->update( $table_name, $data, $where );

        if ( $updated !== false ) {
            error_log('Cell updated successfully.');
            wp_send_json_success();
        } else {
            error_log('Error updating cell: ' . $wpdb->last_error);
            wp_send_json_error( 'Error updating the cell' );
        }
    }

    // Method to add a new row via AJAX
    public function add_row() {
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'dcb_ajax_nonce' ) ) {
            wp_send_json_error( 'Invalid nonce' );
        }

        $state = '';
        $city = '';
        $specialty = '';
        $combo_type = '';
        $content_block = '';
        $content_block_2 = '';

        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';
        $inserted = $wpdb->insert( $table_name, array(
            'state' => $state,
            'city' => $city,
            'specialty' => $specialty,
            'combo_type' => $combo_type,
            'content_block' => $content_block,
            'content_block_2' => $content_block_2,
            'last_updated' => current_time('mysql')
        ));

        if ( $inserted ) {
            wp_send_json_success( array( 'id' => $wpdb->insert_id ) );
        } else {
            wp_send_json_error( 'Error adding new row' );
        }
    }

    // Method to generate content using OpenAI via AJAX
    public function generate_content() {
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'dcb_ajax_nonce' ) ) {
            wp_send_json_error( 'Invalid nonce' );
        }

        $id = isset( $_POST['id'] ) ? intval( $_POST['id'] ) : 0;
        $state = isset( $_POST['state'] ) ? sanitize_text_field( $_POST['state'] ) : '';
        $city = isset( $_POST['city'] ) ? sanitize_text_field( $_POST['city'] ) : '';
        $specialty = isset( $_POST['specialty'] ) ? sanitize_text_field( $_POST['specialty'] ) : '';
        $combo_type = isset( $_POST['combo_type'] ) ? strtolower( trim( sanitize_text_field( $_POST['combo_type'] ) ) ) : '';
        $content_block_number = isset( $_POST['content_block_number'] ) ? intval( $_POST['content_block_number'] ) : 1;

        if ( empty( $state ) && empty( $city ) && empty( $specialty ) && empty( $combo_type ) ) {
            wp_send_json_error( 'At least one field must be filled out.' );
        }

        $api_key = get_option( 'dcb_openai_api_key' );
        $prompt_templates = get_option( 'dcb_prompt_templates', array() );

        if ( empty( $api_key ) ) {
            wp_send_json_error( 'OpenAI API key is not set.' );
        }

        if ( empty( $prompt_templates ) ) {
            wp_send_json_error( 'Prompt templates are not set.' );
        }

        $prompt_template = '';
        if ( ! empty( $combo_type ) ) {
            foreach ( $prompt_templates as $template ) {
                if ( isset( $template['combo_type'] ) && strtolower( trim( $template['combo_type'] ) ) === $combo_type ) {
                    $prompt_template = $template['prompt'];
                    break;
                }
            }
        }

        if ( empty( $prompt_template ) ) {
            wp_send_json_error( 'No prompt template found for the given combo type.' );
        }

        $placeholders = array(
            '{state}'      => $state,
            '{city}'       => $city,
            '{specialty}'  => $specialty,
            '{combo_type}' => $combo_type,
        );

        $prompt = strtr( $prompt_template, $placeholders );

        $response = $this->call_openai_api( $api_key, $prompt );

        if ( is_wp_error( $response ) ) {
            wp_send_json_error( $response->get_error_message() );
        }

        $generated_content = $response;

        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';

        $data = array(
            'last_updated' => current_time( 'mysql' )
        );

        if ( $content_block_number === 1 ) {
            $data['content_block'] = $generated_content;
        } elseif ( $content_block_number === 2 ) {
            $data['content_block_2'] = $generated_content;
        } else {
            wp_send_json_error( 'Invalid content block number.' );
        }

        $updated = $wpdb->update(
            $table_name,
            $data,
            array( 'id' => $id )
        );

        if ( $updated !== false ) {
            if ( $content_block_number === 1 ) {
                wp_send_json_success( array( 'content_block' => $generated_content ) );
            } elseif ( $content_block_number === 2 ) {
                wp_send_json_success( array( 'content_block_2' => $generated_content ) );
            }
        } else {
            wp_send_json_error( 'Error updating the content block.' );
        }
    }

    // Method to get entry count based on combo type
    public function get_entry_count() {
        // Check if the feature is enabled
        if ( ! get_option( 'dcb_auto_generate_enabled', false ) ) {
            wp_send_json_error( 'The Auto Generate All feature is disabled.' );
        }

        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'dcb_ajax_nonce' ) ) {
            wp_send_json_error( 'Invalid nonce' );
        }

        $combo_type = isset( $_POST['combo_type'] ) ? sanitize_text_field( $_POST['combo_type'] ) : '';

        if ( empty( $combo_type ) ) {
            wp_send_json_error( 'Combo Type is required.' );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';

        $count = $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM $table_name WHERE combo_type = %s",
            $combo_type
        ) );

        wp_send_json_success( array( 'count' => intval( $count ) ) );
    }

    // Method to handle bulk content generation
    public function bulk_generate_content() {
        // Check if the feature is enabled
        error_log('bulk_generate_content function called'); // This should log in the PHP error log
        if ( ! get_option( 'dcb_auto_generate_enabled', false ) ) {
            wp_send_json_error( 'The Auto Generate All feature is disabled.' );
        }

        error_log('Nonce received: ' . ( isset( $_POST['nonce'] ) ? $_POST['nonce'] : 'none' ));
        if ( ! isset( $_POST['nonce'] ) || ! wp_verify_nonce( $_POST['nonce'], 'dcb_ajax_nonce' ) ) {
            wp_send_json_error( 'Invalid nonce' );
        }

        $combo_type = isset( $_POST['combo_type'] ) ? sanitize_text_field( $_POST['combo_type'] ) : '';
        $content_block_number = isset( $_POST['content_block_number'] ) ? intval( $_POST['content_block_number'] ) : 1;

        if ( empty( $combo_type ) ) {
            wp_send_json_error( 'Combo Type is required.' );
        }

        if ( $content_block_number !== 1 && $content_block_number !== 2 ) {
            wp_send_json_error( 'Invalid content block number.' );
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';

        $entries = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM $table_name WHERE combo_type = %s",
            $combo_type
        ) );

        if ( empty( $entries ) ) {
            wp_send_json_error( 'No entries found matching the specified Combo Type.' );
        }

        $api_key = get_option( 'dcb_openai_api_key' );
        $prompt_templates = get_option( 'dcb_prompt_templates', array() );

        if ( empty( $api_key ) ) {
            wp_send_json_error( 'OpenAI API key is not set.' );
        }

        if ( empty( $prompt_templates ) ) {
            wp_send_json_error( 'Prompt templates are not set.' );
        }

        $prompt_template = '';
        foreach ( $prompt_templates as $template ) {
            if ( isset( $template['combo_type'] ) && strtolower( trim( $template['combo_type'] ) ) === strtolower( $combo_type ) ) {
                $prompt_template = $template['prompt'];
                break;
            }
        }

        if ( empty( $prompt_template ) ) {
            wp_send_json_error( 'No prompt template found for the given combo type.' );
        }

        foreach ( $entries as $entry ) {
            $state = $entry->state;
            $city = $entry->city;
            $specialty = $entry->specialty;

            $placeholders = array(
                '{state}'      => $state,
                '{city}'       => $city,
                '{specialty}'  => $specialty,
                '{combo_type}' => $combo_type,
            );

            $prompt = strtr( $prompt_template, $placeholders );

            $response = $this->call_openai_api( $api_key, $prompt );

            if ( is_wp_error( $response ) ) {
                error_log( 'OpenAI API error for entry ID ' . $entry->id . ': ' . $response->get_error_message() );
                continue;
            }

            $generated_content = $response;

            $data = array(
                'last_updated' => current_time( 'mysql' )
            );

            if ( $content_block_number === 1 ) {
                $data['content_block'] = $generated_content;
            } else {
                $data['content_block_2'] = $generated_content;
            }

            $updated = $wpdb->update(
                $table_name,
                $data,
                array( 'id' => $entry->id )
            );

            if ( $updated === false ) {
                error_log( 'Database update error for entry ID ' . $entry->id . ': ' . $wpdb->last_error );
            }

            usleep(500000); // 0.5 seconds delay
        }

        wp_send_json_success();
    }

    private function call_openai_api( $api_key, $prompt ) {
        $endpoint = 'https://api.openai.com/v1/chat/completions';

        $args = array(
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $api_key
            ),
            'body' => json_encode( array(
                'model' => 'gpt-3.5-turbo',
                'messages' => array(
                    array( 'role' => 'user', 'content' => $prompt )
                ),
                'temperature' => 0.7,
                'max_tokens' => 500
            ) ),
            'timeout' => 30
        );

        $response = wp_remote_post( $endpoint, $args );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( isset( $data['error'] ) ) {
            return new WP_Error( 'openai_error', $data['error']['message'] );
        }

        if ( isset( $data['choices'][0]['message']['content'] ) ) {
            return $data['choices'][0]['message']['content'];
        }

        return new WP_Error( 'openai_error', 'Unexpected API response.' );
    }
}
?>
