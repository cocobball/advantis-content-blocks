<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class DCB_Combo_Auto_Add {

    public function __construct() {
        add_action('dcb_check_combo', array($this, 'check_and_add_combo'), 10, 4);
    }

    public function check_and_add_combo( $state, $city, $specialty, $combo_type ) {
        // First, check if the feature is enabled in settings
        $feature_enabled = get_option('dcb_combo_auto_add_enabled', '1'); // default is '1' (enabled)
        if ( $feature_enabled !== '1' ) {
            return; // feature is disabled, so do nothing
        }

        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';

        // Build the where clause dynamically based on provided parameters
        $where_clauses = array();
        $params = array();

        if ( $state !== null ) {
            $where_clauses[] = 'state = %s';
            $params[] = $state;
        }
        if ( $city !== null ) {
            $where_clauses[] = 'city = %s';
            $params[] = $city;
        }
        if ( $specialty !== null ) {
            $where_clauses[] = 'specialty = %s';
            $params[] = $specialty;
        }
        if ( $combo_type !== null ) {
            $where_clauses[] = 'combo_type = %s';
            $params[] = $combo_type;
        }

        if ( empty( $where_clauses ) ) {
            return; // No parameters provided, nothing to do
        }

        $where_sql = implode(' AND ', $where_clauses);

        // Check if combination exists
        $sql = "SELECT * FROM $table_name WHERE $where_sql LIMIT 1";
        $existing_combo = $wpdb->get_row( $wpdb->prepare( $sql, $params ) );

        if ( $existing_combo ) {
            // Combination already exists, do nothing
            return;
        }

        // Prepare data for insertion
        $data = array();
        $format = array();

        if ( $state !== null ) {
            $data['state'] = $state;
            $format[] = '%s';
        }
        if ( $city !== null ) {
            $data['city'] = $city;
            $format[] = '%s';
        }
        if ( $specialty !== null ) {
            $data['specialty'] = $specialty;
            $format[] = '%s';
        }
        if ( $combo_type !== null ) {
            $data['combo_type'] = $combo_type;
            $format[] = '%s';
        }

        // Add placeholders for content blocks
        $data['content_block'] = '';
        $data['content_block_2'] = '';
        $format[] = '%s';
        $format[] = '%s';

        // Insert the new combination into the database
        $wpdb->insert( $table_name, $data, $format );
    }
}
