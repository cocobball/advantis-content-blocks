<?php

class DCB_Database {
    public static function create_table() {
        global $wpdb;
        $table_name      = $wpdb->prefix . 'dcb_content_blocks';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE $table_name (
            id INT NOT NULL AUTO_INCREMENT,
            state VARCHAR(255),
            city VARCHAR(255),
            specialty VARCHAR(255),
            combo_type VARCHAR(255),
            content_block LONGTEXT,
            content_block_2 LONGTEXT,
            last_updated DATETIME,
            PRIMARY KEY (id)
        ) $charset_collate;";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );
    }

    public static function drop_table() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'dcb_content_blocks';
        $sql        = "DROP TABLE IF EXISTS $table_name;";
        $wpdb->query( $sql );
    }
}
