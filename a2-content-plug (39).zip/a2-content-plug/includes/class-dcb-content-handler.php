<?php

class DCB_Content_Handler {
    private $table_name;

    public function __construct() {
        global $wpdb;
        $this->table_name = $wpdb->prefix . 'dcb_content_blocks';
    }

    /**
     * Retrieve a content block based on state, city, specialty, and combo_type.
     */
    public function get_content_block( $state = null, $city = null, $specialty = null, $combo_type = null ) {
        global $wpdb;
        $query = "SELECT * FROM {$this->table_name} WHERE 1=1";
        $conditions = array();
        $params = array();

        // State condition - only if passed
        if ($state !== null) {
            if ($state === '') {
                $conditions[] = "(state IS NULL OR state = '')";
            } else {
                $conditions[] = "state = %s";
                $params[] = $state;
            }
        }

        // City condition - only if passed
        if ($city !== null) {
            if ($city === '') {
                $conditions[] = "(city IS NULL OR city = '')";
            } else {
                $conditions[] = "city = %s";
                $params[] = $city;
            }
        }

        // Specialty condition - only if passed
        if ($specialty !== null) {
            if ($specialty === '') {
                $conditions[] = "(specialty IS NULL OR specialty = '')";
            } else {
                $conditions[] = "specialty = %s";
                $params[] = $specialty;
            }
        }

        // Combo Type condition - only if passed
        if ($combo_type !== null) {
            if ($combo_type === '') {
                $conditions[] = "(combo_type IS NULL OR combo_type = '')";
            } else {
                $conditions[] = "combo_type = %s";
                $params[] = $combo_type;
            }
        }

        // Combine conditions
        if (!empty($conditions)) {
            $query .= ' AND ' . implode(' AND ', $conditions);
        }

        $query .= " LIMIT 1";

        // Prepare and execute the query
        if (!empty($params)) {
            $prepared_query = $wpdb->prepare($query, $params);
        } else {
            $prepared_query = $query;
        }

        $result = $wpdb->get_row($prepared_query, ARRAY_A);

        return $result;
    }

    /**
     * Insert a new content block into the database.
     */
    public function insert_content_block($state, $city, $specialty, $combo_type, $content_block, $content_block_2) {
        global $wpdb;
        $wpdb->insert(
            $this->table_name,
            array(
                'state'          => $state,
                'city'           => $city,
                'specialty'      => $specialty,
                'combo_type'     => $combo_type,
                'content_block'  => $content_block,
                'content_block_2' => $content_block_2,
                'last_updated'   => current_time('mysql'),
            ),
            array('%s', '%s', '%s', '%s', '%s', '%s', '%s')
        );
        return $wpdb->insert_id;
    }

    /**
     * Retrieve all content blocks.
     */
    public function get_all_content_blocks() {
        global $wpdb;
        $results = $wpdb->get_results("SELECT * FROM {$this->table_name}", ARRAY_A);
        return $results;
    }
}
