<?php

class DCB_Shortcode {

    public function __construct() {
        add_shortcode( 'dcb_content_block', array( $this, 'render_content_block' ) );
    }

    public function render_content_block( $atts ) {
        // Shortcode usage examples:
        // [dcb_content_block state="Texas" city="Dallas" combo_type="type1" block_number="1"]
        // [dcb_content_block specialty="Cardiology" combo_type="type2" block_number="2"]

        // Set default attributes, including combo_type for specifying the combo type
        $atts = shortcode_atts( array(
            'state'         => null,
            'city'          => null,
            'specialty'     => null,
            'combo_type'    => null, // New attribute to specify combo type
            'block_number'  => 1, // Specify which content block to display
        ), $atts, 'dcb_content_block' );

        global $post;

        // Only auto-fill from post meta if explicitly set to an empty string in the shortcode
        if ($atts['state'] === '') {
            $atts['state'] = get_post_meta( $post->ID, 'geolocation_state_long', true );
        }
        if ($atts['city'] === '') {
            $atts['city'] = get_post_meta( $post->ID, 'geolocation_city', true );
        }
        if ($atts['specialty'] === '') {
            $atts['specialty'] = get_post_meta( $post->ID, 'specialty', true );
        }

        // Sanitize the attributes, leaving nulls as is
        $state = $atts['state'] !== null ? sanitize_text_field( $atts['state'] ) : null;
        $city = $atts['city'] !== null ? sanitize_text_field( $atts['city'] ) : null;
        $specialty = $atts['specialty'] !== null ? sanitize_text_field( $atts['specialty'] ) : null;
        $combo_type = $atts['combo_type'] !== null ? sanitize_text_field( $atts['combo_type'] ) : null;

        // Log the parameters for debugging
        error_log('Shortcode Params: state=' . ($state ?: 'NULL') . ', city=' . ($city ?: 'NULL') . ', specialty=' . ($specialty ?: 'NULL') . ', combo_type=' . ($combo_type ?: 'NULL'));

        // Trigger the action to check and add combo if necessary
        do_action('dcb_check_combo', $state, $city, $specialty, $combo_type);

        $content_handler = new DCB_Content_Handler();
        $content_block = $content_handler->get_content_block( $state, $city, $specialty, $combo_type );

        if ( $content_block ) {
            // Check the block_number attribute to determine which content block to display
            if ( intval( $atts['block_number'] ) === 2 ) {
                return $content_block['content_block_2'];
            } else {
                return $content_block['content_block'];
            }
        } else {
            return ''; // Or return a default message if no content block is found
        }
    }
}
