<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly.
}

class DCB_URL_Shortcode {

    public function __construct() {
        add_shortcode('content_from_url', array($this, 'display_taxonomy_content_from_url'));
    }

    // Shortcode to display content based on URL parameters
    public function display_taxonomy_content_from_url() {
        // Get the current URL path
        $current_url = $_SERVER['REQUEST_URI'];

        // Break down the URL into parts
        $url_parts = explode('/', trim($current_url, '/'));

        // Assuming the structure is: domain.com/travel-nurse-jobs/{state}/{specialty}
        $state = isset($url_parts[2]) ? sanitize_text_field($url_parts[2]) : ''; // "alaska"
        $specialty = isset($url_parts[3]) ? sanitize_text_field($url_parts[3]) : ''; // "ct-tech"

        if (!$state || !$specialty) {
            return 'Unable to display content. State or specialty not found in URL.';
        }

        // Query the taxonomy or post type using the extracted state and specialty
        $args = array(
            'post_type' => 'your_custom_post_type', // Adjust this to your post type
            'tax_query' => array(
                'relation' => 'AND',
                array(
                    'taxonomy' => 'state',
                    'field'    => 'slug',
                    'terms'    => $state,
                ),
                array(
                    'taxonomy' => 'specialty',
                    'field'    => 'slug',
                    'terms'    => $specialty,
                ),
            ),
        );

        // Fetch the posts that match the state and specialty
        $query = new WP_Query($args);
        if ($query->have_posts()) {
            $output = '<div class="content-boxes">';
            while ($query->have_posts()) {
                $query->the_post();
                // Customize the output format for each post
                $output .= '<div class="content-box">';
                $output .= '<h2>' . get_the_title() . '</h2>';
                $output .= '<p>' . get_the_excerpt() . '</p>';
                $output .= '</div>';
            }
            wp_reset_postdata();
            $output .= '</div>';
            return $output;
        } else {
            return 'No content found for the specified state and specialty.';
        }
    }
}
