<?php
// Uninstall routines can be added here.