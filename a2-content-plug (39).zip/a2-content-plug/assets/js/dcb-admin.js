jQuery(document).ready(function($) {

    // Log nonce for debugging
    console.log('Nonce:', dcbAjax.nonce);

    // Delete individual row
    $('#dcb-spreadsheet-table').on('click', '.dcb-delete-row', function(e) {
        e.preventDefault();
        var $row = $(this).closest('tr');
        var id = $row.data('id');

        if (confirm('Are you sure you want to delete this row?')) {
            console.log('Payload for deleting row:', {
                action: 'dcb_delete_row',
                id: id,
                nonce: dcbAjax.nonce
            });

            $.ajax({
                url: dcbAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'dcb_delete_row',
                    id: id,
                    nonce: dcbAjax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $row.remove();
                    } else {
                        alert('Error deleting row: ' + response.data);
                    }
                },
                error: function() {
                    alert('An error occurred while trying to delete the row.');
                }
            });
        }
    });

    // Inline editing
    $('#dcb-spreadsheet-table').on('blur', '[contenteditable="true"]', function() {
        var $cell = $(this);
        var value = $cell.text();
        var field = $cell.data('field');
        var id = $cell.closest('tr').data('id');

        $.ajax({
            url: dcbAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'dcb_save_cell',
                nonce: dcbAjax.nonce,
                id: id,
                field: field,
                value: value
            },
            success: function(response) {
                if (response.success) {
                    $cell.closest('tr').find('.last-updated').text(new Date().toLocaleString());
                } else {
                    alert('Error updating cell: ' + response.data);
                }
            },
            error: function() {
                alert('An error occurred while trying to save the cell.');
            }
        });
    });

    // Add row
    $('#dcb-add-row').on('click', function() {
        $.ajax({
            url: dcbAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'dcb_add_row',
                nonce: dcbAjax.nonce
            },
            success: function(response) {
                if (response.success) {
                    var newRow = '<tr data-id="' + response.data.id + '">' +
                        '<td contenteditable="true" data-field="state"></td>' +
                        '<td contenteditable="true" data-field="city"></td>' +
                        '<td contenteditable="true" data-field="specialty"></td>' +
                        '<td contenteditable="true" data-field="combo_type"></td>' +
                        '<td contenteditable="true" data-field="content_block"></td>' +
                        '<td contenteditable="true" data-field="content_block_2"></td>' + 
                        '<td class="last-updated"></td>' + 
                        '<td>' +
                            '<button class="button dcb-generate-row">Generate</button>' +
                            '<button class="button dcb-generate-row-2">Generate 2</button>' +
                            '<button class="button dcb-delete-row">Delete</button>' +
                        '</td>' +
                        '</tr>';
                    $('#dcb-spreadsheet-table tbody').append(newRow);
                } else {
                    alert('Error adding new row: ' + response.data);
                }
            },
            error: function() {
                alert('An error occurred while trying to add a new row.');
            }
        });
    });

    // Delete all rows
    $('#dcb-delete-all').on('click', function() {
        if (confirm('Are you sure you want to delete all rows?')) {
            $.ajax({
                url: dcbAjax.ajax_url,
                type: 'POST',
                data: {
                    action: 'dcb_delete_all',
                    nonce: dcbAjax.nonce
                },
                success: function(response) {
                    if (response.success) {
                        $('#dcb-spreadsheet-table tbody').empty();
                    } else {
                        alert('Error deleting all rows: ' + response.data);
                    }
                },
                error: function() {
                    alert('An error occurred while trying to delete all rows.');
                }
            });
        }
    });

    // Handler for "Auto Generate All" button
    $('#dcb-auto-generate-all-btn').on('click', function(e) {
        e.preventDefault();
        console.log('Auto Generate button clicked'); // Check if this logs in Console

        var comboType = $('#dcb-combo-type').val().trim();
        var contentBlockNumber = $('#dcb-content-block-select').val();

        if (!comboType) {
            alert('Please enter a Combo Type.');
            return;
        }

        // First AJAX call to get the count of entries matching the combo_type
        $.ajax({
            url: dcbAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'dcb_get_entry_count',
                nonce: dcbAjax.nonce,
                combo_type: comboType
            },
            success: function(response) {
                if (response.success) {
                    var count = response.data.count;

                    if (count == 0) {
                        alert('No entries found matching the specified Combo Type.');
                        return;
                    }

                    if (confirm('This will generate content for ' + count + ' entries. Do you want to proceed?')) {
                        // User confirmed, proceed with bulk generation
                        $.ajax({
                            url: dcbAjax.ajax_url,
                            type: 'POST',
                            data: {
                                action: 'dcb_bulk_generate_content',
                                nonce: dcbAjax.nonce,
                                combo_type: comboType,
                                content_block_number: contentBlockNumber
                            },
                            success: function(response) {
                                if (response.success) {
                                    alert('Content generated successfully for ' + count + ' entries.');
                                } else {
                                    alert('Error generating content: ' + response.data);
                                }
                            },
                            error: function() {
                                alert('An error occurred while generating content.');
                            }
                        });
                    } else {
                        return;
                    }
                } else {
                    alert('Error fetching entry count: ' + response.data);
                }
            },
            error: function() {
                alert('An error occurred while fetching entry count.');
            }
        });
    });

    // Generate Button Handler for Content Block 1
    $('#dcb-spreadsheet-table').on('click', '.dcb-generate-row', function(e) {
        e.preventDefault();
        var $row = $(this).closest('tr');
        var id = $row.data('id');

        // Collect data from the row
        var state = $row.find('[data-field="state"]').text();
        var city = $row.find('[data-field="city"]').text();
        var specialty = $row.find('[data-field="specialty"]').text();
        var combo_type = $row.find('[data-field="combo_type"]').text();

        if (!state && !city && !specialty && !combo_type) {
            alert('Please fill in at least one field before generating content.');
            return;
        }

        $.ajax({
            url: dcbAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'dcb_generate_content',
                nonce: dcbAjax.nonce,
                id: id,
                state: state,
                city: city,
                specialty: specialty,
                combo_type: combo_type,
                content_block_number: 1
            },
            success: function(response) {
                if (response.success) {
                    $row.find('[data-field="content_block"]').text(response.data.content_block);
                    $row.find('.last-updated').text(new Date().toLocaleString());
                } else {
                    alert('Error generating content: ' + response.data);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log('AJAX error response for Generate:', textStatus, errorThrown);
                console.log('Detailed Error:', jqXHR.responseText);
                var errorMessage = 'An error occurred while trying to generate content.';
                if (jqXHR.responseJSON && jqXHR.responseJSON.data) {
                    errorMessage += '\n' + jqXHR.responseJSON.data;
                }
                alert(errorMessage);
            }
        });
    });

    // Generate Button Handler for Content Block 2
    $('#dcb-spreadsheet-table').on('click', '.dcb-generate-row-2', function(e) {
        e.preventDefault();
        var $row = $(this).closest('tr');
        var id = $row.data('id');

        var state = $row.find('[data-field="state"]').text();
        var city = $row.find('[data-field="city"]').text();
        var specialty = $row.find('[data-field="specialty"]').text();
        var combo_type = $row.find('[data-field="combo_type"]').text();

        if (!state && !city && !specialty && !combo_type) {
            alert('Please fill in at least one field before generating content.');
            return;
        }

        $.ajax({
            url: dcbAjax.ajax_url,
            type: 'POST',
            data: {
                action: 'dcb_generate_content',
                nonce: dcbAjax.nonce,
                id: id,
                state: state,
                city: city,
                specialty: specialty,
                combo_type: combo_type,
                content_block_number: 2
            },
            success: function(response) {
                if (response.success) {
                    $row.find('[data-field="content_block_2"]').text(response.data.content_block_2);
                    $row.find('.last-updated').text(new Date().toLocaleString());
                } else {
                    alert('Error generating content: ' + response.data);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log('AJAX error response for Generate 2:', textStatus, errorThrown);
                console.log('Detailed Error:', jqXHR.responseText);
                var errorMessage = 'An error occurred while trying to generate content.';
                if (jqXHR.responseJSON && jqXHR.responseJSON.data) {
                    errorMessage += '\n' + jqXHR.responseJSON.data;
                }
                alert(errorMessage);
            }
        });
    });

});
