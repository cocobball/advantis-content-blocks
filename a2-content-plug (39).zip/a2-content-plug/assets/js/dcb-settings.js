jQuery(document).ready(function($) {
    // Add new prompt template row
    $('#dcb-add-prompt').on('click', function(e) {
        e.preventDefault();
        var index = $('#dcb-prompt-templates-table tbody tr').length; // Get current row count as the index
        var row = '<tr>' +
            '<td><input type="text" name="dcb_prompt_combo_types[' + index + ']" value="" /></td>' +
            '<td><textarea name="dcb_prompt_prompts[' + index + ']" rows="3" cols="50"></textarea></td>' +
            '<td><button class="button dcb-remove-prompt">' + dcbSettings.removeText + '</button></td>' +
            '</tr>';
        $('#dcb-prompt-templates-table tbody').append(row);
    });

    // Remove prompt template row and reindex the remaining rows
    $('#dcb-prompt-templates-table').on('click', '.dcb-remove-prompt', function(e) {
        e.preventDefault();
        $(this).closest('tr').remove();

        // Reindex the name attributes after removing a row
        $('#dcb-prompt-templates-table tbody tr').each(function(index) {
            $(this).find('input[name^="dcb_prompt_combo_types"]').attr('name', 'dcb_prompt_combo_types[' + index + ']');
            $(this).find('textarea[name^="dcb_prompt_prompts"]').attr('name', 'dcb_prompt_prompts[' + index + ']');
        });
    });
});
